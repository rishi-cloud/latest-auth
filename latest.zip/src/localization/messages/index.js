import en from "./en-US";
import fr from "./fr-CA";

const messages = {
    ...en,
    ...fr,
};
export default messages;
