export const LOCALES = {
    ENGLISH: "en-us",
    GERMAN: "de-de",
    FRENCH: "fr-ca",
};
