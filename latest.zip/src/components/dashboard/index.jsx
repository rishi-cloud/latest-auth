import React from "react";

import DashboardUI from "./dashboard";
const DashBoard = (props) => {
    return <DashboardUI />;
};
export default DashBoard;
