import React from "react";
import "./style.css";

function CircularLoader() {
  return (
    <div className="lds-ring">
      <div></div>
      <div></div>
      <div></div>
      <div></div>
    </div>
  );
}

export default CircularLoader;
