# cnsr-odrplat-auth0-ui
Is a React project which will have the UI for auth0 login
